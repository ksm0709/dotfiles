#ifndef SOFTSYNC_H
#define SOFTSYNC_H
typedef struct s_softsync_data SOFTSYNC_DATA;

#endif
