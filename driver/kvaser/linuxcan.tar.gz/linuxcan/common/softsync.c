/*
**                         Copyright 2015 by Kvaser AB
**                        Aminogatan 24, Molndal, Sweden
**                          WWW: http://www.kvaser.com
**
** This software is furnished under a license and may be used and copied
** only in accordance with the terms of such license.
**
** Description:
** Functions to let devices appear synchronized by means of software 
** translations of all time stamps to and from the dito.
**
** ---------------------------------------------------------------------------
*/

